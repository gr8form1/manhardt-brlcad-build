# Manhardt Audio — ADR-001 P4.3.5 Developer Static Correction Submission

**Date:** November 8, 2026. **Disposition:** SOURCE-ONLY TESTS 151/151 PASS; INDEPENDENT RELEASE ACCEPTANCE PENDING; NO RUNTIME EXECUTION AUTHORIZED.

## Controlling failure and provenance

Independent failed-run attribution `ADR001_P434_Run42548941447_Independent_Failure_Attribution_2026-11-08.md` reports GitHub run 42548941447 failure after same-run security preflight PASS, at the first `sha256sum /runtime/bin/step-g` call with permission denied. Raw GitHub artifact (48,992 bytes) SHA-256 `cd05dbc5d23f69b5b534449f22167ff32d87c130af978de68984916f2664c6da` authenticated and retained by Drive. No glibc ABI evidence was collected. Original Build #5 expires 2026-11-09 15:56:29 UTC; expiration remains HOLD without founder-approved alternative.

Exact reviewed P4.3.4 source-only baseline SHA-256 `a68cce76e8de5fa93f6ccc335e596ccf8fb68e53e3fc86a781af725daff4a7a6`; outer P4.3.4 candidate SHA-256 `7ad228fb4c6e7d8116856163ffeac8a3ddc83c53ee7bccddac9d7b375e43ed40`. Only `ci/p4_abi_controller.py` and `ci/test_p4_abi_protocol.py` differ. The other 12/12 source files, including all ten frozen P3.2.1 controls, proposed P4 workflow, frozen ELF manifest and public canary, are byte-identical. P4-R2 scratch cleanup implementation remains source-identical; the host `scratch.mkdir(mode=0o700)` and Docker UID 65534, readonly binds, nonroot/nonnetwork/cgroup constraints are unchanged.

## Corrective source change

1. Following the **authenticated** `safe_extract_runtime()` and exact binary SHA checks, `_authenticated_runtime_public_files` derives the attested 2,410-file source census. `_public_tree_manifest` rejects unexpected files, directories, symlinks, nonregular entries, invalid paths, prior digest mismatches, chmod errors and post-chmod mode/hash mismatches. It applies mode **0755** to all directories under the disposable `/runtime` bind source; regular files are **0644** except the explicit `bin/step-g` (0755). It never chmods the private scratch parent, which remains 0700.
2. Following independently authenticated **public fixture** blob/Git/hash checks, the same gate applies 0755 to the `/fixtures` source directory and 0644 to each approved fixture. Complete exact file SHA identities are checked both before and after permission normalization. The permission receipt distinguishes **static UID/GID 65534 mode-bit accessibility** from untested in-container access and ABI.
3. The ABI-only shell adds `test -r` gates for the two binary files and two unmodified fixtures **before** running `sha256sum` or GNU-loader diagnostics. This performs no step-g invocation, plugin dispatch or STEP conversion.

The frozen `.github/workflows/adr001-public-ap242-p4-abi-proposal.yml`, `ci/ap242_preflight.py`, source pins, Docker image and original Build #5 bytes are unchanged. The accepted P4.3.4 canary-to-ABI provenance splitter, ABI evidence framing, provider identity HOLD and cleanup controls are retained.

## Exact clean-source tests and evidence

Fresh extraction from `PUBLICATION/P435_PROPOSED_SOURCE_ONLY_14_FILES.zip`; before/after file census **14**. Python `-I -B`: security **49/49 PASS**, P4 protocol **102/102 PASS** (all **88** original methods retained, **14** new P4.3.5 methods). Total **151/151 PASS**. `sh -n` ABI shell PASS; workflow YAML static parse PASS. Source AST checks PASS. No Docker or BRL-CAD binary execution. Full test streams/exit codes/hashes in `EVIDENCE/P435_CLEAN_SOURCE_TEST_RECEIPT.json`.

The new tests exercise `umask 077` root/child 0700 failure mode; after preparation, full 0755 directory traversal / 0644 file readability, and synthetic-only nonexecuting UID 65534 file reads when the offline test host permits a local drop of identity. Injected symlinks, unexpected/missing files or dirs, invalid paths, digest mismatches, chmod failure, silently unchanged modes and post-chmod byte mutation all fail closed. The private scratch parent mode remains 0700 in the actual permission gate test. No production binary executed.

The archive includes exact `P434_TO_P435_EXACT_SOURCE.diff`, source Git blob SHA-1 / SHA-256 / sizes, clean-checkout logs, syntactic inspection, and authenticated original failure metadata. The exact diff was reapplied with zero fuzz to the frozen 14-source P4.3.4 baseline, reproducing all 14 candidate files.

## Authorization boundaries

**Independent static acceptance pending; P4.3.5 not approved for publication.** Do not retry run 42548941447. New publication, controlled approval variable and any future one-shot ABI-only workflow dispatch are **separate founder authorization gates** after independent review. G1 actual provider ABI, G2–G6, all private CAD and scientific qualification remain HOLD. No Work, Lenovo/audio, purchases or capital actions; October 18 capital STOP remains effective. No Build #5 substitute or rebuild.
